package application;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

public class FoodItemController implements Initializable{

	@FXML
	private TextField itemName;

	@FXML
	private TextField itemPrice;

	@FXML
	private ChoiceBox <String> choiceBox;

	@FXML
	private Button submitButton;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		choiceBox.getItems().add("Beef");
		choiceBox.getItems().add("Chicken");
		choiceBox.getItems().add("Pizza");
		choiceBox.getItems().add("Hotdog");
		choiceBox.getItems().add("Appetizer");
		choiceBox.getItems().add("Noodles");
		choiceBox.getItems().add("Seafood");
		choiceBox.getItems().add("Kid");
		choiceBox.getItems().add("Sides");
		choiceBox.getItems().add("Beverages");

		submitButton.setOnAction(e -> SubmitChanges(e));

	}

	@FXML
	void SubmitChanges(ActionEvent event){
		String name = itemName.getText();
		double price = Double.parseDouble(itemPrice.getText());
		String itemCategory = choiceBox.getValue();

		String beef = "C://Users//tamda//Desktop//FinalLab//fooditem//beef.txt";
		String seafood = "C://Users//tamda//Desktop//FinalLab//fooditem//seafood.txt";
		String appetizer = "C://Users//tamda//Desktop//FinalLab//fooditem//appetizer.txt";
		String chicken = "C://Users//tamda//Desktop//FinalLab//fooditem//chicken.txt";
		String pizza = "C://Users//tamda//Desktop//FinalLab//fooditem//pizza.txt";
		String hotdog = "C://Users//tamda//Desktop//FinalLab//fooditem//hotdog.txt";
		String noodles = "C://Users//tamda//Desktop//FinalLab//fooditem//noodles.txt";
		String kid = "C://Users//tamda//Desktop//FinalLab//fooditem//kidmenu.txt";
		String beverages = "C://Users//tamda//Desktop//FinalLab//fooditem//beverages.txt";
		String sides = "C://Users//tamda//Desktop//FinalLab//fooditem//sides.txt";

		try {
			switch(itemCategory){
				case "Beef":
					SaveCategoryChoice(beef);
				case "Seafood":
					SaveCategoryChoice(seafood);
				case "Appetizer":
					SaveCategoryChoice(appetizer);
				case "Chicken":
					SaveCategoryChoice(chicken);
				case "Pizza":
					SaveCategoryChoice(pizza);
				case "Hotdog":
					SaveCategoryChoice(hotdog);
				case "Noodles":
					SaveCategoryChoice(noodles);
				case "Kid":
					SaveCategoryChoice(kid);
				case "Beverages":
					SaveCategoryChoice(beverages);
				default:
					SaveCategoryChoice(sides);
			} //end switch
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void SaveCategoryChoice(String fileName) throws IOException{
		ArrayList<String> itemName = new ArrayList<String>();
		ArrayList<String> itemPrice = new ArrayList<String>();
		File fp = new File(fileName);
		Scanner scan = new Scanner(fp);
		while(scan.hasNextLine()){
			String line = scan.nextLine();
			String values [] = line.split(" ");
			itemName.add(values[0]);
			itemPrice.add(values[1]);
		}
		scan.close();
		FileWriter write = new FileWriter(fp, false);
		for(int i = 0; i < itemName.size()-1; i ++){
			String newLine = itemName.get(i) + " " + itemPrice.get(i);
			write.write(newLine);
		}
		write.close();


	}


}
