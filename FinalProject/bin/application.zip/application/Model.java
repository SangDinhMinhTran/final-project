package application;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Model {

	public void ReadEmployeeFile(ArrayList<Employee> employ) throws IOException{
		File fp = new File("C:\\Users\\tamda\\Desktop\\FinalLab\\employee.txt");
		int i = 0;
		Scanner scan = new Scanner(fp);
		while(scan.hasNextLine()){
			String line = scan.nextLine();
			String [] values = line.split(" ");
			Employee newEm = new Employee(values[0], Integer.parseInt(values[1]));
			newEm.SetGender(values[2]);
			newEm.SetDateOfBirth(values[3]);
			newEm.SetPhoneNumber(4);
			employ.add(newEm);
			i++;
		}
		scan.close();
	}

}
