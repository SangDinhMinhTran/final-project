package application;

import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class SalaryController {

	@FXML
	private TextField ID;

	@FXML
	private DatePicker DOB;

	@FXML
	private Button submitButton;

	@FXML
	private Button homeButton;

	@FXML
	private ListView<String> list;

	@FXML
	private TextArea totalSalary;

	ArrayList<Employee> employ = new ArrayList<Employee>();
	Model mod = new Model();

	@FXML
	void HandleSubmitButton(ActionEvent event) throws IOException{
		int employeeID = Integer.parseInt(ID.getText());
		String dateOfBirth = DOB.getValue().format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
		mod.ReadEmployeeFile(employ);
		for(int i=0; i < employ.size()-1; i++){
			if(employeeID == employ.get(i).GetUserID() && dateOfBirth.equalsIgnoreCase(employ.get(i).GetDateOfBirth())){

			}
		}
	}


	@FXML
	void HandleHomeButton(ActionEvent event) throws IOException{
		Pane pane = FXMLLoader.load(getClass().getResource("Selection.fxml"));
		Scene scene = new Scene(pane);
		Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
	}

}
