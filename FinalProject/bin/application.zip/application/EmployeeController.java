package application;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class EmployeeController implements Initializable {

	@FXML
	private TextField name;

	@FXML
	private TextField passCode;

	@FXML
	private DatePicker DOB;

	@FXML
	private RadioButton maleButton;

	@FXML
	private RadioButton femaleButton;

	@FXML
	private ImageView malePic;

	@FXML
	private ImageView femalePic;

	@FXML
	private ImageView initialPic;

	@FXML
	private Button doneButton;

	@FXML
	private Button cancelButton;

	@FXML
	private TextField phoneNumber;

	@FXML
	private Pane pane;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		malePic.setVisible(false);
		femalePic.setVisible(false);
		initialPic.setVisible(true);
		maleButton.setOnAction(e -> HandleMaleButton(e));
		femaleButton.setOnAction(e -> HandleFemaleButton(e));
		cancelButton.setOnAction(e -> HandleCancelButton(e));

	}

	@FXML
	void HandleDoneButton(ActionEvent event) throws IOException{
		String gender;
		Boolean IsEmployeeExist = false;
		ArrayList<Employee> employ = new ArrayList<Employee>();
		try {
			File fp = new File("C:\\Users\\tamda\\Desktop\\FinalLab\\employee.txt");
			int i = 0;
			Scanner scan = new Scanner(fp);
			while(scan.hasNextLine()){
				String line = scan.nextLine();
				String [] values = line.split(" ");
				Employee newEm = new Employee(values[0], Integer.parseInt(values[1]));
				newEm.SetGender(values[2]);
				newEm.SetDateOfBirth(values[3]);
				newEm.SetPhoneNumber(Integer.parseInt(values[4]));
				employ.add(newEm);
				i++;
			}
			scan.close();
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//end catch

		String newEmployeeName = name.getText();
		int newEmployeeID = Integer.parseInt(passCode.getText());
		if(maleButton.isSelected()){
			gender = "male";
		}else {
			gender = "female";
		}
		String dateOfBirth = DOB.getValue().format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
		int newPhoneNumber = Integer.parseInt(phoneNumber.getText());
		for(int i = 0; i < employ.size()-1; i++){
			if(newEmployeeID == employ.get(i).GetUserID()){
				employ.get(i).SetDateOfBirth(dateOfBirth);
				employ.get(i).SetGender(gender);
				employ.get(i).SetName(newEmployeeName);
				employ.get(i).SetPhoneNumber(newPhoneNumber);
				IsEmployeeExist = true;
				break;
			}
		}

		if(IsEmployeeExist == false){
			Employee newEm = new Employee(newEmployeeName, newEmployeeID);
			newEm.SetDateOfBirth(dateOfBirth);
			newEm.SetGender(gender);
			newEm.SetPhoneNumber(newPhoneNumber);
			employ.add(newEm);
		}
		try {
		File order = new File("C:\\Users\\tamda\\Desktop\\FinalLab\\employee.txt");
		FileWriter write = new FileWriter(order, false);
		for(int i =0; i < employ.size()-1; i++){
			String employeeLine = employ.get(i).GetName() + " " + employ.get(i).GetUserID() + " " + employ.get(i).GetGender() + " " + employ.get(i).GetDateOfBirth() + " " + employ.get(i).GetPhoneNumber();
			write.write(employeeLine);
		}


		write.close();
		} catch (IOException e){
		// TODO Auto-generated catch block
		e.printStackTrace();
		}//end catch


	}//end handle done button

	@FXML
	void HandleCancelButton(ActionEvent event){
		name.clear();
		passCode.clear();
		phoneNumber.clear();
		DOB.setValue(null);
		femalePic.setVisible(false);
		malePic.setVisible(false);
		femaleButton.setSelected(false);
		maleButton.setSelected(false);
		initialPic.setVisible(true);

	}

	@FXML
	void HandleFemaleButton(ActionEvent event){
		maleButton.setSelected(false);
		malePic.setVisible(false);
		femalePic.setVisible(true);
		initialPic.setVisible(false);
	}

	@FXML
	void HandleMaleButton(ActionEvent event){
		femaleButton.setSelected(false);
		malePic.setVisible(true);
		femalePic.setVisible(false);
		initialPic.setVisible(false);
	}

	@FXML
	void HandleHomeButton(ActionEvent event) throws IOException{
		Pane pane = FXMLLoader.load(getClass().getResource("Selection.fxml"));
		Scene scene = new Scene(pane);
		Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
	}
}
