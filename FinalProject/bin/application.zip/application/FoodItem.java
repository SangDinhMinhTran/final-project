package application;

public class FoodItem {

	String name, category;
	double price;

	public FoodItem(String name, double price, String category){
		this.name = name;
		this.price = price;
		this.category = category;
	}

	public String GetName(){
		return this.name;
	}

	public String GetCategory(){
		return this.category;
	}

	public double GetPrice(){
		return this.price;
	}

	public void SetName(String name){
		this.name = name;
	}

	public void SetPrice(double price){
		 this.price = price;
	}

	 public void SetCategory(String category){
		 this.category = category;
	 }



}
