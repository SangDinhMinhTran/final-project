package application;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class MainController implements Initializable {

	ArrayList<Employee> employ = new ArrayList<Employee>();
	Model mod = new Model();

	@FXML
	private PasswordField passField;

	@FXML
	private Button loginButton;

	@FXML
	private Pane pane;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		try {
			mod.ReadEmployeeFile(employ);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		loginButton.setOnAction(e -> {
			try {
				Login(e);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});
	}


	@FXML
	void Login(ActionEvent event) throws IOException{
		Boolean isValid = true;
		Alert alert = new Alert(AlertType.NONE);
		int pass = Integer.parseInt(passField.getText());
		for (int i = 0; i < employ.size()-1; i++){
			if(pass == employ.get(i).GetUserID()){
				isValid = true;
			}else{
				isValid = false;
			}
		}
		if(isValid == true){
			try {
				SimpleDateFormat dtf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
				Date currentDate = Calendar.getInstance().getTime();
				File fp = new File("C:\\Users\\tamda\\Desktop\\FinalLab\\employeelogins.txt");
				FileWriter writer = new FileWriter(fp, true);
				String currentDateTime = dtf.format(currentDate);
				String loginID = passField.getText() + " " + currentDateTime +"\n";
				writer.write(loginID);

				writer.close();
			}catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			pane = FXMLLoader.load(getClass().getResource("Selection.fxml"));
			Scene scene = new Scene(pane);
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(scene);
			window.show();

		}else {
			alert.setAlertType(AlertType.ERROR);
			alert.setHeaderText(null);
			alert.setTitle("Error!");
			alert.setContentText("Passcode does not exist");
			alert.show();
		}


	}


}
