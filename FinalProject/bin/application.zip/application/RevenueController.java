package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.scene.control.DatePicker;
import javafx.scene.layout.Pane;

public class RevenueController {

	@FXML
	private DatePicker start;

	@FXML
	private DatePicker end;

	@FXML
	private LineChart<String, Double> lineChart;

	Alert alert = new Alert(Alert.AlertType.NONE);

	@FXML
	void HandleSubmitButton(ActionEvent event) throws FileNotFoundException{

		ArrayList<String> dates = new ArrayList<String>();
		ArrayList<Double> sales = new ArrayList<Double>();

		XYChart.Series <String, Double> series = new XYChart.Series<String, Double>();
		series.setName("Sales by Dates");
		String startDate = start.getValue().format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
		String endDate = end.getValue().format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
		File fp = new File("C:\\Users\\tamda\\Desktop\\FinalLab\\revenue.txt");
		Scanner scan = new Scanner(fp);
		while (scan.hasNextLine()){
			String newLine = scan.nextLine();
			String values[] = newLine.split(" ");
			dates.add(values[0]);
			sales.add(Double.parseDouble(values[1]));
		}
		scan.close();

		if(startDate.compareTo(endDate) == 1){
			alert.setAlertType(AlertType.ERROR);
			alert.setHeaderText(null);
			alert.setTitle("Error");
			alert.setContentText("End date cannot be less than start date");
			alert.show();
		}
		if(!dates.contains(startDate) || !dates.contains(endDate)){
			alert.setAlertType(AlertType.ERROR);
			alert.setHeaderText(null);
			alert.setTitle("Error");
			alert.setContentText("Dates are not in range");
			alert.show();
		} else{
			int startIndex = dates.indexOf(startDate), endIndex = dates.indexOf(endDate);

			for(int i = startIndex; i <= endIndex; i++){
				series.getData().add(new XYChart.Data<String, Double>(dates.get(i), sales.get(i)));
				lineChart.getData().add(series);
			}


		}

	}//end handle submit

	@FXML
	void HandleHomeButton(ActionEvent event) throws IOException{
		Pane pane = FXMLLoader.load(getClass().getResource("Selection.fxml"));
		Scene scene = new Scene(pane);
		Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();

	}

}
