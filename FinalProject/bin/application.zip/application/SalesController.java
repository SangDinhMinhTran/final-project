package application;



import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class SalesController implements Initializable {


	@FXML
	private Button saveButton;

	@FXML
	private Button cancelButton;

	@FXML
	private AnchorPane itemDisplay;

	@FXML
	private AnchorPane tableDisplay;

	@FXML
	private Button beefButton;

	@FXML
	private Button appetizerButton;

	@FXML
	private Button seafoodButton;

	@FXML
	private Button pizzaButton;

	@FXML
	private Button noodlesButton;

	@FXML
	private Button hotdogButton;

	@FXML
	private Button beveragesButton;

	@FXML
	private Button kidButton;

	@FXML
	private Button sidesButton;

	@FXML
	private Button chickenButton;

	@FXML
	private TextArea billTotal;

	@FXML
	private TextArea orderDetails;

	@FXML
	private ListView<String> list;

	@FXML
	private RadioButton dineInButton;

	@FXML
	private RadioButton togoButton;

	@FXML
	private ChoiceBox<String> tableChoice;

	String orderType;
	int appetizerCount=0, kidCount=0, seafoodCount=0, beefCount=0, chickenCount=0, sidesCount=0;
	int hotdogCount=0,beveragesCount=0, noodlesCount=0, pizzaCount=0;


	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		billTotal.setText("0");

		appetizerButton.setOnAction(e -> HandleAppetizerButton(e));
		kidButton.setOnAction(e -> HandleKidButton(e));
		seafoodButton.setOnAction(e -> HandleSeafoodButton(e));
		beefButton.setOnAction(e -> HandleBeefButton(e));
		chickenButton.setOnAction(e -> HandleChickenButton(e));
		sidesButton.setOnAction(e -> HandleSidesButton(e));
		hotdogButton.setOnAction(e -> HandleHotdogButton(e));
		pizzaButton.setOnAction(e -> HandlePizzaButton(e));
		beveragesButton.setOnAction(e -> HandleBeveragesButton(e));
		noodlesButton.setOnAction(e -> HandleNoodlesButton(e));
		dineInButton.setOnAction(e -> HandleDineIn(e));
		togoButton.setOnAction(e -> HandleToGo(e));
		saveButton.setOnAction(e -> HandleSaveButton(e));
		cancelButton.setOnAction(e -> HandleCancelButton(e));

	}

	@FXML
	void HandleSaveButton(ActionEvent event){
		if(dineInButton.isSelected()){
			orderType = "dine in";
		}else {
			orderType = "to go";
		}
		String date = " ", employeeID= " ";
		String amount = billTotal.getText();
		try{
			File fp = new File("C:\\Users\\tamda\\Desktop\\FinalLab\\employeelogins.txt");
			BufferedReader br = new BufferedReader(new FileReader(fp));

			String lastLine = "";
			while((lastLine = br.readLine()) != null ){
				if(lastLine != null){
					String values[] = lastLine.split(" ", 2);
					employeeID = values[0];
					date = values[1];
				}

			}//end while

			File order = new File("C:\\Users\\tamda\\Desktop\\FinalLab\\order.txt");
			FileWriter write = new FileWriter(order, true);
			String orderLine = employeeID + " " + amount + " " + orderType + " " + date + "\n";
			write.write(orderLine);
			write.close();
			br.close();

			//return to the main screen
			Pane pane = FXMLLoader.load(getClass().getResource("Selection.fxml"));
			Scene scene = new Scene(pane);
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(scene);
			window.show();


		}catch(IOException e){
			e.printStackTrace();
		}
	}

	@FXML
	void HandleCancelButton(ActionEvent event){
		list.getItems().clear();
		dineInButton.setSelected(false);
		togoButton.setSelected(false);
		list.getItems().clear();
		dineInButton.setSelected(false);
		togoButton.setSelected(false);
		tableChoice.getItems().clear();
		billTotal.clear();

	}

	@FXML
	void HandleToGo(ActionEvent event){
		dineInButton.setSelected(false);
		tableChoice.setDisable(true);
		orderDetails.setText("To Go");
	}

	@FXML
	void HandleDineIn(ActionEvent event){
		tableChoice.setDisable(false);
		togoButton.setSelected(false);
		tableChoice.getItems().add("A1");
		tableChoice.getItems().add("A2");
		tableChoice.getItems().add("A3");
		tableChoice.getItems().add("A4");
		tableChoice.getItems().add("A5");
		orderDetails.setText("Dine In");
	}

	@FXML
	void HandleAppetizerButton(ActionEvent event){
		String appe = "Appetizer" + "\t\t" + "$9";
		list.getItems().add(appe);
		int bill = Integer.parseInt(billTotal.getText()) + 9;
		billTotal.setText(Integer.toString(bill));
		pizzaCount++;

	}

	@FXML
	void HandleKidButton(ActionEvent event){
		String appe = "Kid" + "\t\t\t" + "$9";
		list.getItems().add(appe);
		int bill = Integer.parseInt(billTotal.getText()) + 9;
		billTotal.setText(Integer.toString(bill));
		kidCount++;
	}

	@FXML
	void HandleBeefButton(ActionEvent event){
		String appe = "Beef" + "\t\t\t" + "$9";
		list.getItems().add(appe);
		int bill = Integer.parseInt(billTotal.getText()) + 9;
		billTotal.setText(Integer.toString(bill));
		beefCount++;
	}

	@FXML
	void HandleNoodlesButton(ActionEvent event){
		String appe = "Noodle" + "\t\t" + "$9";
		list.getItems().add(appe);
		int bill = Integer.parseInt(billTotal.getText()) + 9;
		billTotal.setText(Integer.toString(bill));
		noodlesCount++;
	}

	@FXML
	void HandleSeafoodButton(ActionEvent event){
		String appe = "Seafood" + "\t\t" + "$9";
		list.getItems().add(appe);
		int bill = Integer.parseInt(billTotal.getText()) + 9;
		billTotal.setText(Integer.toString(bill));
		seafoodCount++;
	}

	@FXML
	void HandleHotdogButton(ActionEvent event){
		String appe = "Hotdog" + "\t\t" + "$9";
		list.getItems().add(appe);
		int bill = Integer.parseInt(billTotal.getText()) + 9;
		billTotal.setText(Integer.toString(bill));
		hotdogCount++;
	}

	@FXML
	void HandlePizzaButton(ActionEvent event){
		String appe = "Pizza" + "\t\t" + "$9";
		list.getItems().add(appe);
		int bill = Integer.parseInt(billTotal.getText()) + 9;
		billTotal.setText(Integer.toString(bill));
		pizzaCount++;
	}

	@FXML
	void HandleBeveragesButton(ActionEvent event){
		String appe = "Coke" + "\t\t\t" + "$9";
		list.getItems().add(appe);
		int bill = Integer.parseInt(billTotal.getText()) + 9;
		billTotal.setText(Integer.toString(bill));
		beveragesCount++;
	}

	@FXML
	void HandleSidesButton(ActionEvent event){
		String appe = "Sides" + "\t\t\t" + "$9";
		list.getItems().add(appe);
		int bill = Integer.parseInt(billTotal.getText()) + 9;
		billTotal.setText(Integer.toString(bill));
		sidesCount++;
	}

	@FXML
	void HandleChickenButton(ActionEvent event){
		String appe = "Chicken" + "\t\t\t" + "$9";
		list.getItems().add(appe);
		int bill = Integer.parseInt(billTotal.getText()) + 9;
		billTotal.setText(Integer.toString(bill));
		chickenCount++;
	}

}
