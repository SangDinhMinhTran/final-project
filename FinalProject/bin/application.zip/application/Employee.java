package application;

public class Employee {

	public String name, dateOfBirth, gender;
	public int userID, phoneNumber;

	public Employee(String name, int userID){
		this.name = name;
		this.userID = userID;
	}

	public String GetName(){
		return name;
	}

	public String GetDateOfBirth(){
		return dateOfBirth;
	}

	public String GetGender(){
		return gender;
	}

	public int GetUserID(){
		return userID;
	}

	public int GetPhoneNumber(){
		return phoneNumber;
	}

	public void SetName(String name){
		this.name = name;
	}

	public void SetUserID(int userID){
		this.userID = userID;
	}

	public void SetDateOfBirth(String dateOfBirth){
		this.dateOfBirth = dateOfBirth;
	}

	public void SetPhoneNumber(int phoneNum){
		this.phoneNumber = phoneNum;
	}

	public void SetGender(String gen){
		this.gender = gen;
	}

}
